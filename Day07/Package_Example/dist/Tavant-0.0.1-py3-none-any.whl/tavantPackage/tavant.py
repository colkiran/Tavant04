
gstName = "Sachin Tendulkar"

runs = {'odis': 23450, 'test': 26500, 't20': 3500}

sports = ['cricket', 'hockey', 'football', 'tennis', 'basketball', 'swimming']

# ------------------------------------------------------------------

def greet(gname):
    print(f"Greetings Mr. {gname}, Welcome to the event.....")

# ------------------------------------------------------------------

class Employee:

    def __init__(self, name, age):
        self.name = name
        self.age = age

    def get_details(self):
        print(f"Name :{self.name}\nAge :{self.age}")

# ------------------------------------------------------------------

def sum(x, y):
    return x + y

